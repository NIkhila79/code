export const environment = {
    production: false,
    apiUrlGlobal: 'http://10.245.240.102:8060/smartpra/proration/fca/'
  };