import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProrationComponent } from './proration.component';

describe('ProrationComponent', () => {
  let component: ProrationComponent;
  let fixture: ComponentFixture<ProrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
