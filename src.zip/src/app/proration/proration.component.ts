import { Component, OnInit } from '@angular/core';
// import { FormControl } from '@angular/forms';
import { ProrationService } from '../services/proration.service';
import { DatepickerOptions } from 'ng2-datepicker';


@Component({
  selector: 'app-proration',
  templateUrl: './proration.component.html',
  styleUrls: ['./proration.component.css']
})
export class ProrationComponent implements OnInit {
  dataToSend:any={};
  prorationList :Array<any> = [];
  prorationJson: any = {};
  myRadio: string = 'create';
  flightDate: string =""; 
  options: DatepickerOptions = {
    displayFormat: 'YYYY-MM-DD',
    addClass: 'form-control'   
  };

  addFieldValue() {
    this.prorationList.push(this.prorationJson);
    this.prorationJson = {};
  }

  deleteFieldValue(index) {
    this.prorationList.splice(index, 1);
  }

  constructor(private prorationService :ProrationService) { }

  ngOnInit() {
    //console.log(this.proration);
    this.prorationList.push(JSON.parse(JSON.stringify((this.prorationJson)))); 
    this.flightDate= new Date().toISOString().split('T')[0];
    console.log("flightDate-test",this.flightDate);
  }



  onSubmit(){
    console.log(this.prorationList);
    const json = {
      "gfp":{
        "listOfCoupons" :this.prorationList
      },
      "fcaString" : this.dataToSend["fcaString"],
      "ticketType" : this.myRadio
    }
    console.log("json",JSON.stringify(json));
    // this.prorationService.addAirport(this.addNewAirportForm.value).subscribe(
    //   airportservice => {
    //     console.log(data);
        
    //   });
  }

  allowNumbersOnly(e: any) {
    var code = (e.which) ? e.which : e.keyCode;
    if (code > 31 && (code < 48 || code > 57)) {
      e.preventDefault();
    }
  }

}
