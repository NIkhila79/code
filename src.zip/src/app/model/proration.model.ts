export class Proration {
docNo: string;
couponNo: string;
origin: string;
destination: string;
cxr: string;
flightDateFormat: string;
fareBasis: string;
fcaString: string;
 constructor() { }

}