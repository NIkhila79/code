import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';


declare var $;
import swal from 'sweetalert2';

import { Proration } from '../model/proration.model';
import { environment } from '../environments/environment';
const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ProrationService {
  globalUrl = environment.apiUrlGlobal;
  constructor(private http: HttpClient) { }
  /** POST: add a new airport to the server */
  addAirport(proration){
    return this.http.post(this.globalUrl + 'enrichgfp/', proration, httpOptions).pipe(
    );
  }

  // addAirport (): Observable<Proration[]> {
  //   return this.http.get<Proration[]>(this.heroesUrl)
  //     .pipe(
  //       catchError(this.handleError('getHeroes', []))
  //     );
  //     return this.http.post<Proration[]>(this.globalUrl + 'enrichgfp/', proration, httpOptions).pipe(
  //       catchError(this.handleError('getHeroes', [])) 
  //       );
  //     }

}
