import { TestBed } from '@angular/core/testing';

import { ProrationService } from './proration.service';

describe('ProrationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProrationService = TestBed.get(ProrationService);
    expect(service).toBeTruthy();
  });
});
